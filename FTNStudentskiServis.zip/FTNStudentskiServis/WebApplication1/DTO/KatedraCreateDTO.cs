﻿namespace WebApplication1.DTO
{
    public class KatedraCreateDTO
    {
        public string Naziv { get; set; }
    }
}
