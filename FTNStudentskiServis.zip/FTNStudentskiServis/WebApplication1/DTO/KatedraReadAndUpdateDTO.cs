﻿namespace WebApplication1.DTO
{
    public class KatedraReadAndUpdateDTO
    {
        public int Id { get; set; }
        public string Naziv { get; set; }
        public List<string> Smerovi { get; set; }
    }
}
