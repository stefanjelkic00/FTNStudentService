﻿namespace WebApplication1.DTO
{
    public class PrijavaStudentaReadAndUpdateDTO
    {
        public int Id { get; set; }
        public string StudentIndex { get; set; }
        public string PredmetNaziv { get; set; }
    }
}
