﻿namespace WebApplication1.DTO
{
    public class OcenaDTO
    {
        public int PrijavaId { get; set; }
        public int Ocena { get; set; }
        public int PredmetId { get; set; }
        public int StudentId { get; set; }
    }
}
