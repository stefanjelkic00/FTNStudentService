﻿namespace WebApplication1.DTO
{
    public class PrijavaStudentaCreateDTO
    {
       
        public int PredmetId { get; set; }
    }
}
