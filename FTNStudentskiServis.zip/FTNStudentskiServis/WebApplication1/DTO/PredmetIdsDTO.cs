﻿namespace WebApplication1.DTO
{
    public class PredmetIdsDTO
    {
        public List<int> PredmetIds { get; set; }
    }
}