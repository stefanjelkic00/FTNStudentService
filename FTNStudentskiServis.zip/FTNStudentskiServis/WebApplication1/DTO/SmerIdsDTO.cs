﻿namespace WebApplication1.DTO
{
    public class SmerIdsDTO
    {
        public List<int> SmerIds { get; set; }
    }

}
