﻿namespace WebApplication1.DTO
{
    public class PredmetCreateDTO
    {
        public string Naziv { get; set; }
        public int BrojEspb { get; set; }
    }
}
