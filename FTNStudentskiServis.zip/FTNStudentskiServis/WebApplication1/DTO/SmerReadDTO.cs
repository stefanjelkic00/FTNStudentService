﻿namespace WebApplication1.DTO
{
    public class SmerReadDTO
    {
        public int Id { get; set; }
        public string Naziv { get; set; }
    }

}
