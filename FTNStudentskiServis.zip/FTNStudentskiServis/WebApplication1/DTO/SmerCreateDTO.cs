﻿namespace WebApplication1.DTO
{
    public class SmerCreateDTO
    {
        public string Naziv { get; set; }
    }
}