﻿namespace WebAPLIKACIJAVEZBANJE.Enums
{
    public enum Role
    {
        Admin,
        Student,
        Profesor
    }
}
