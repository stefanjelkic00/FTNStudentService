﻿namespace WebAPLIKACIJAVEZBANJE.Enums
{
    public enum StatusIspita
    {
        Polozen,
        Nepolozen
    }
}

